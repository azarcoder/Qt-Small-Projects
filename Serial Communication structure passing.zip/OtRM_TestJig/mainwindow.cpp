#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    this->setWindowTitle("OrRM Testjig");
    init_gui();
    create_objects();
    connect_signals_and_slots();

    //check every 3s for any comport loaded
    m_timer = new QTimer(this);
    connect(m_timer, &QTimer::timeout, this, &MainWindow::load_available_com_ports_into_comboBox);
    m_timer->start(5000);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::set_link_sts(bool b_sts)
{
    if(b_sts)
    {
        ui->frame_link_uart->setStyleSheet("background-color: green; border-radius : 10px");
        ui->label_link_uart->setStyleSheet("color: white;");
    }
    else
    {

        ui->frame_link_uart->setStyleSheet("background-color: red; border-radius : 10px");
        ui->label_link_uart->setStyleSheet("color: white;");
    }
}

void MainWindow::init_gui()
{
    set_link_sts(false);
    enable_disable_connection_button(false);
    load_available_com_ports_into_comboBox();
    ui->textEdit_Rx->setReadOnly(true);
}

void MainWindow::create_objects()
{
    m_serialPort = new QSerialPort(this);
    set_serialPort_configuration();
}

void MainWindow::set_serialPort_configuration()
{
    //    serialPort->setPortName(portName); //default port if user want
    m_serialPort->setBaudRate(QSerialPort::Baud115200);
    m_serialPort->setDataBits(QSerialPort::Data8);
    m_serialPort->setParity(QSerialPort::NoParity);
    m_serialPort->setStopBits(QSerialPort::OneStop);
    m_serialPort->setFlowControl(QSerialPort::NoFlowControl);
}

void MainWindow::enable_disable_connection_button(bool connection)
{
    if(connection)
    {
        ui->pushButton_connect->setDisabled(true);
        ui->pushButton_disconnect->setDisabled(false);
        ui->comboBox->setDisabled(true);
        ui->pushButton_connect->setStyleSheet("background-color: gray; color : white;");
        ui->pushButton_disconnect->setStyleSheet("background-color: rgb(220, 20, 60);color:#fff");

    }
    else
    {
        ui->pushButton_connect->setDisabled(false);
        ui->comboBox->setDisabled(false);
        ui->pushButton_disconnect->setDisabled(true);

        ui->pushButton_disconnect->setStyleSheet("background-color: gray; color : white;");
        ui->pushButton_connect->setStyleSheet("color:#fff;background-color: rgb(34, 139, 34);");
    }
}

void MainWindow::connect_signals_and_slots()
{
    connect(ui->textEdit_Tx, &QTextEdit::textChanged, this, &MainWindow::slot_custom_text_edit_format);
    connect(m_serialPort, &QSerialPort::readyRead,this, &MainWindow::slot_read_data);
}

QByteArray MainWindow::parse_data(QString data)
{
    QByteArray out_parsed_Bytedata;
    QString parsed_data;
    QStringList list = data.split("|");
    for(int i = 0; i < list.size(); i++)
    {
        parsed_data += list.at(i).trimmed();
    }
    out_parsed_Bytedata =  QByteArray::fromHex(parsed_data.toLatin1());
    return  out_parsed_Bytedata;
}


void MainWindow::load_available_com_ports_into_comboBox()
{
    ui->comboBox->clear();

    const auto ports = QSerialPortInfo::availablePorts();
    for(const QSerialPortInfo &port : ports)
    {
        ui->comboBox->addItem(port.portName());
    }
}

void MainWindow::on_pushButton_connect_clicked()
{
    m_serialPort->setPortName(ui->comboBox->currentText());

    //if already open close and reconnect
    if(m_serialPort->isOpen())
    {
        m_serialPort->close();
    }

    if(m_serialPort->open(QIODevice::ReadWrite))
    {
        set_link_sts(true);
        enable_disable_connection_button(true);
        m_timer->stop();

        ui->comboBox->setCurrentIndex(ui->comboBox->findText(m_serialPort->portName()));
    }
    else
    {
        if (m_serialPort->error() == QSerialPort::PermissionError) {
            QMessageBox::critical(this, "Error",
                                  "The selected COM port is already open in another program.\n"
                                  "Please close that program and try again.");
        } else {
            QMessageBox::critical(this, "Error",
                                  "Failed to open port: " + m_serialPort->errorString());
        }

        set_link_sts(false);
        enable_disable_connection_button(false);
    }

}


void MainWindow::on_pushButton_disconnect_clicked()
{
    if (m_serialPort->isOpen()) {
        m_serialPort->close();
        set_link_sts(false);
        enable_disable_connection_button(false);
        m_timer->start(3000);

    }
}

void MainWindow::slot_custom_text_edit_format()
{
    QString text = ui->textEdit_Tx->toPlainText();

    //remove non hex
    text.remove(QRegularExpression("[^0-9A-Fa-f]"));

    //make upper
    text = text.toUpper();

    // add |
    QString formatted;
    for(int i = 0; i < text.length(); i++)
    {
        if(i > 0 && i % 2 == 0)
        {
            formatted += " | ";
        }
        formatted += text[i];
    }

    // Limit to 50 bytes (=> 2 chars each)
    int maxChars = 50 * 2 + (49 * 3); // 50 bytes, plus separators
    if (formatted.length() > maxChars) {
        formatted = formatted.left(maxChars);
    }

    //Block signal to avoid recursion & update text
    ui->textEdit_Tx->blockSignals(true);
    ui->textEdit_Tx->setPlainText(formatted);
    ui->textEdit_Tx->moveCursor(QTextCursor::End); // keep cursor at end
    ui->textEdit_Tx->blockSignals(false);

}

void MainWindow::frame_data(S_TX_PACKET *out_pS_Tx_Packet)
{
    QByteArray ByteData = parse_data(ui->textEdit_Tx->toPlainText());
    out_pS_Tx_Packet->ui_Header = MESSAGE_HEADER;
    out_pS_Tx_Packet->ui_DataLength = ByteData.length();
    out_pS_Tx_Packet->byte_Data = ByteData;

    quint32 checksum = 0;
    foreach(auto b , ByteData)
        checksum ^= static_cast<quint8>(b);
    out_pS_Tx_Packet->ui_CheckSum = checksum;

}

QByteArray MainWindow::serialize_packet(const S_TX_PACKET &packet)
{
    QByteArray sendData;
    QDataStream stream(&sendData, QIODevice::WriteOnly);
    stream.setByteOrder(QDataStream::LittleEndian);

    stream << packet.ui_Header;
    stream << packet.ui_DataLength;
    stream.writeRawData(packet.byte_Data.constData(), packet.byte_Data.size());
    stream << packet.ui_CheckSum;

    return sendData;
}

void MainWindow::parse_rx_buffer()
{
    while(m_rxBuffer.size() >= 12) // minimum size: header(4) + length(4) + checksum(4)
    {
        quint32 header = *reinterpret_cast<const quint32*>(m_rxBuffer.constData());

        if(header != MESSAGE_HEADER)
        {
            // bad header, remove first byte and try again
            m_rxBuffer.remove(0,1); //(pos,len) removing one byte
            continue;
        }

        // read data length
        quint32 dataLen = *reinterpret_cast<const quint32*>(m_rxBuffer.constData() + 4);

        // check if whole packet is received
        if(m_rxBuffer.size() < (int)(12 + dataLen)) break; // wait for more bytes

        // extract packet
        S_TX_PACKET packet;
        packet.ui_Header = header;
        packet.ui_DataLength = dataLen;
        packet.byte_Data = m_rxBuffer.mid(8, dataLen); // data - slice from 8 to datalen
        packet.ui_CheckSum = *reinterpret_cast<const quint32*>(m_rxBuffer.constData() + 8 + dataLen);

        // remove parsed bytes from buffer
        m_rxBuffer.remove(0, 12 + dataLen);

//        qDebug() << "recieved full data : " << "header : " << packet.ui_Header << " length:" << packet.ui_DataLength << " data : " << packet.byte_Data
//                 << " checksum:" << packet.ui_CheckSum;

        // now you can process the packet
        process_packet(packet);
    }

}

void MainWindow::process_packet(const S_TX_PACKET &packet)
{
    QString hexString = packet.byte_Data.toHex(' ').toUpper();
//    qDebug() << "Received Bytes" << hexString;s
    ui->textEdit_Rx->insertPlainText(hexString + " ");
    ui->textEdit_Rx->moveCursor(QTextCursor::End);
}


void MainWindow::on_pushButton_send_clicked()
{
    ui->textEdit_Rx->clear();
    S_TX_PACKET S_Tx_packet;
    frame_data(&S_Tx_packet);


    QByteArray sendData = serialize_packet(S_Tx_packet);

    if(m_serialPort->isOpen())
    {
        m_serialPort->write(sendData);
        m_serialPort->flush();
    }

    qDebug() << "Sent bytes:" << sendData.toHex(' ').toUpper();

}

void MainWindow::slot_read_data()
{
    QByteArray data = m_serialPort->readAll();
    m_rxBuffer.append(data);

    parse_rx_buffer();
}

