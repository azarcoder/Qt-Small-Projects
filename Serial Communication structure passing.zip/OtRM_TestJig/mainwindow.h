#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QSerialPortInfo>
#include <QSerialPort>
#include <QTimer>
#include <QRegularExpression>
#include <QRegularExpressionValidator>
#include <QDebug>
#include <QtGlobal>
#include <QMessageBox>

#define MESSAGE_HEADER  0xABCD1234




QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

    typedef struct
    {
        quint32       ui_Header;
        quint32       ui_DataLength;
        QByteArray    byte_Data;
        quint32       ui_CheckSum;

    }S_TX_PACKET;

private slots:
    void set_link_sts(bool b_sts);

    void load_available_com_ports_into_comboBox();

    void on_pushButton_connect_clicked();

    void on_pushButton_disconnect_clicked();

    void slot_custom_text_edit_format();

    void on_pushButton_send_clicked();

    void slot_read_data();

private:
    Ui::MainWindow *ui;

    QSerialPort *m_serialPort = nullptr;
    QTimer *m_timer;
    QByteArray m_rxBuffer;

    void init_gui();
    void create_objects();
    void set_serialPort_configuration();
    void enable_disable_connection_button(bool connection);
    void connect_signals_and_slots();
    QByteArray parse_data(QString data);
    void frame_data(S_TX_PACKET *out_pS_Tx_Packet);
    QByteArray serialize_packet(const S_TX_PACKET &packet);
    void parse_rx_buffer();
    void process_packet(const S_TX_PACKET &packet);
};
#endif // MAINWINDOW_H
