#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QSerialPortInfo>
#include <QSerialPort>
#include <QTimer>
#include <QRegularExpression>
#include <QRegularExpressionValidator>
#include <QDebug>


QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void set_link_sts(bool b_sts);

    void load_available_com_ports_into_comboBox();

    void on_pushButton_connect_clicked();

    void on_pushButton_disconnect_clicked();

    void slot_custom_text_edit_format();

    void on_pushButton_send_clicked();

    void slot_read_data();

private:
    Ui::MainWindow *ui;

    QSerialPort *m_serialPort = nullptr;
    QTimer *m_timer;

    void init_gui();
    void create_objects();
    void set_serialPort_configuration();
    void enable_disable_connection_button(bool connection);
    void connect_signals_and_slots();
    QByteArray parse_data(QString data);
};
#endif // MAINWINDOW_H
